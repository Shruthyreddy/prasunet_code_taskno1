// script.js

window.addEventListener('scroll', function() {
    const navbar = document.getElementById('navbar');
    const links = navbar.querySelectorAll('a');
    if (window.scrollY > 50) {
        navbar.style.backgroundColor = '#555'; // Change background color on scroll
        links.forEach(link => link.style.color = '#ff9800'); // Change font color on scroll
    } else {
        navbar.style.backgroundColor = '#333'; // Original background color
        links.forEach(link => link.style.color = 'white'); // Original font color
    }
});
